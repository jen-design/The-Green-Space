# The Green Space


TITLE:
The Green Space
QA Term Project


AUTHOR:
Jen Smith
A00833618

CLASS:
Quality Assurance MDIA 4590
BCIT New Media and Web Development 2020


CREDITS:

Bootstrap
http://getbootstrap.com/

jQuery
http://jquery.com/

jQuery Easing
http://gsgd.co.uk/sandbox/jquery/easing/

Modernizr
http://modernizr.com/

jQuery Cookie
https://github.com/carhartl/jquery-cookie

Viewport-Units-Buggyfill
https://github.com/rodneyrehm/viewport-units-buggyfill/

Google Fonts
https://www.google.com/fonts/

Icomoon
https://icomoon.io/app/

Respond JS
https://github.com/scottjehl/Respond/blob/master/LICENSE-MIT

animate.css
http://daneden.me/animate

jQuery Waypoint
https://github.com/imakewebthings/waypoints/blog/master/licenses.txt

Demo Images:
http://unsplash.com
